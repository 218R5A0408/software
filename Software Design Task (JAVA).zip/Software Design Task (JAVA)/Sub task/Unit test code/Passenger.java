import java.util.ArrayList;
import java.util.List;

class Passenger {
    private String name;
    private String passengerNumber;
    private String passengerType;
    private double balance;
    private List<Activity> activitiesSignedUp;

    public Passenger(String name, String passengerNumber, String passengerType, double balance) {
        this.name = name;
        this.passengerNumber = passengerNumber;
        this.passengerType = passengerType;
        this.balance = balance;
        this.activitiesSignedUp = new ArrayList<>();
    }

    public boolean signUpForActivity(Activity activity) {
        // Implementation
    }

    // Getters and other methods
}

class Activity {
    private String name;
    private String description;
    private double cost;
    private int capacity;
    private int currentCapacity;
    private Destination destination;

    public Activity(String name, String description, double cost, int capacity) {
        this.name = name;
        this.description = description;
        this.cost = cost;
        this.capacity = capacity;
        this.currentCapacity = 0;
    }

    // Getters and other methods
}

class Destination {
    private String name;
    private List<Activity> activities;

    public Destination(String name) {
        this.name = name;
        this.activities = new ArrayList<>();
    }

    public void addActivity(Activity activity) {
        activities.add(activity);
        activity.setDestination(this);
    }

    // Getters and other methods
}

class TravelPackage {
    private String name;
    private int passengerCapacity;
    private List<Destination> itinerary;
    private List<Passenger> passengers;

    public TravelPackage(String name, int passengerCapacity, List<Destination> itinerary) {
        this.name = name;
        this.passengerCapacity = passengerCapacity;
        this.itinerary = itinerary;
        this.passengers = new ArrayList<>();
    }

    public void addPassenger(Passenger passenger) {
        // Implementation
    }

    // Other methods as per specification
}

public class Main {
    public static void main(String[] args) {
        // Example usage
    }
}
