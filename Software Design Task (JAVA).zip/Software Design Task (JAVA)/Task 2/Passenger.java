import java.util.ArrayList;
import java.util.List;

class Passenger {
    private String name;
    private String passengerNumber;
    private String passengerType;
    private double balance;
    private List<Activity> activitiesSignedUp;

    public Passenger(String name, String passengerNumber, String passengerType, double balance) {
        this.name = name;
        this.passengerNumber = passengerNumber;
        this.passengerType = passengerType;
        this.balance = balance;
        this.activitiesSignedUp = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public String getPassengerNumber() {
        return passengerNumber;
    }

    public String getPassengerType() {
        return passengerType;
    }

    public double getBalance() {
        return balance;
    }

    public boolean signUpForActivity(Activity activity) {
        if (activity.isAvailable()) {
            double cost = activity.getCost();
            if (passengerType.equals("standard")) {
                if (balance >= cost) {
                    balance -= cost;
                    activitiesSignedUp.add(activity);
                    activity.incrementCurrentCapacity();
                    return true;
                }
            } else if (passengerType.equals("gold")) {
                double discountedCost = cost * 0.9;
                if (balance >= discountedCost) {
                    balance -= discountedCost;
                    activitiesSignedUp.add(activity);
                    activity.incrementCurrentCapacity();
                    return true;
                }
            } else if (passengerType.equals("premium")) {
                activitiesSignedUp.add(activity);
                activity.incrementCurrentCapacity();
                return true;
            }
        }
        return false;
    }

    public List<Activity> getActivitiesSignedUp() {
        return activitiesSignedUp;
    }
}

class Activity {
    private String name;
    private String description;
    private double cost;
    private int capacity;
    private int currentCapacity;
    private Destination destination;

    public Activity(String name, String description, double cost, int capacity) {
        this.name = name;
        this.description = description;
        this.cost = cost;
        this.capacity = capacity;
        this.currentCapacity = 0;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public double getCost() {
        return cost;
    }

    public int getCapacity() {
        return capacity;
    }

    public int getCurrentCapacity() {
        return currentCapacity;
    }

    public boolean isAvailable() {
        return currentCapacity < capacity;
    }

    public void incrementCurrentCapacity() {
        currentCapacity++;
    }

    public Destination getDestination() {
        return destination;
    }

    public void setDestination(Destination destination) {
        this.destination = destination;
    }
}

class Destination {
    private String name;
    private List<Activity> activities;

    public Destination(String name) {
        this.name = name;
        this.activities = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public List<Activity> getActivities() {
        return activities;
    }

    public void addActivity(Activity activity) {
        activities.add(activity);
        activity.setDestination(this);
    }
}

class TravelPackage {
    private String name;
    private int passengerCapacity;
    private List<Destination> itinerary;
    private List<Passenger> passengers;

    public TravelPackage(String name, int passengerCapacity, List<Destination> itinerary) {
        this.name = name;
        this.passengerCapacity = passengerCapacity;
        this.itinerary = itinerary;
        this.passengers = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public int getPassengerCapacity() {
        return passengerCapacity;
    }

    public List<Destination> getItinerary() {
        return itinerary;
    }

    public List<Passenger> getPassengers() {
        return passengers;
    }

    public void addPassenger(Passenger passenger) {
        if (passengers.size() < passengerCapacity) {
            passengers.add(passenger);
        }
    }

    public void printItinerary() {
        System.out.println("Travel Package: " + name);
        for (Destination destination : itinerary) {
            System.out.println("\nDestination: " + destination.getName());
            for (Activity activity : destination.getActivities()) {
                System.out.println("- Activity: " + activity.getName() + ", Description: " + activity.getDescription() + ", Cost: " + activity.getCost() + ", Capacity: " + activity.getCapacity());
            }
        }
    }

    public void printPassengerList() {
        System.out.println("Travel Package: " + name);
        System.out.println("Passenger Capacity: " + passengerCapacity);
        System.out.println("Number of Passengers Enrolled: " + passengers.size());
        System.out.println("Passenger List:");
        for (Passenger passenger : passengers) {
            System.out.println("- Name: " + passenger.getName() + ", Passenger Number: " + passenger.getPassengerNumber());
        }
    }

    public void printPassengerDetails(String passengerNumber) {
        for (Passenger passenger : passengers) {
            if (passenger.getPassengerNumber().equals(passengerNumber)) {
                System.out.println("Passenger Name: " + passenger.getName());
                System.out.println("Passenger Number: " + passenger.getPassengerNumber());
                System.out.println("Balance: " + passenger.getBalance());
                System.out.println("Activities Signed Up:");
                for (Activity activity : passenger.getActivitiesSignedUp()) {
                    System.out.println("- Destination: " + activity.getDestination().getName() + ", Activity: " + activity.getName() + ", Cost: " + activity.getCost());
                }
                return;
            }
        }
        System.out.println("Passenger with number " + passengerNumber + " not found.");
    }

    public void printAvailableActivities() {
        System.out.println("Available Activities:");
        for (Destination destination : itinerary) {
            for (Activity activity : destination.getActivities()) {
                if (activity.isAvailable()) {
                    System.out.println("- Destination: " + destination.getName() + ", Activity: " + activity.getName() + ", Available Spaces: " + (activity.getCapacity() - activity.getCurrentCapacity()));
                }
            }
        }
    }
}

public class Main {
    public static void main(String[] args) {
        Destination destination1 = new Destination("Mountain Resort");
        Destination destination2 = new Destination("Beach Resort");

        Activity activity1 = new Activity("Hiking", "Enjoy a hike in the mountains.", 20, 10);
        Activity activity2 = new Activity("Scuba Diving", "Explore the underwater world.", 50, 5);

        destination1.addActivity(activity1);
        destination2.addActivity(activity2);

        List<Destination> itinerary = new ArrayList<>();
        itinerary.add(destination1);
        itinerary.add(destination2);

        TravelPackage travelPackage = new TravelPackage("Adventure Package", 10, itinerary);

        Passenger passenger1 = new Passenger("John Doe", "P001", "standard", 100);
        Passenger passenger2 = new Passenger("Jane Doe", "P002", "gold", 200);
        Passenger passenger3 = new Passenger("Alice Smith", "P003", "premium", 0);

        travelPackage.addPassenger(passenger1);
        travelPackage.addPassenger(passenger2);
        travelPackage.addPassenger(passenger3);

        passenger1.signUpForActivity(activity1);
        passenger2.signUpForActivity(activity2);

        travelPackage.printItinerary();
        travelPackage.printPassengerList();
        travelPackage.printPassengerDetails("P001");
        travelPackage.printAvailableActivities();
    }
}
