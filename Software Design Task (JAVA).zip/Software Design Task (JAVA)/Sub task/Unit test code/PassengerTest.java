import org.junit.Test;
import static org.junit.Assert.*;

public class PassengerTest {
    
    @Test
    public void testSignUpForActivity() {
        Passenger passenger = new Passenger("John Doe", "P001", "standard", 100);
        Activity activity = new Activity("Hiking", "Enjoy a hike in the mountains.", 20, 10);
        assertTrue(passenger.signUpForActivity(activity));
    }
    
  
}
